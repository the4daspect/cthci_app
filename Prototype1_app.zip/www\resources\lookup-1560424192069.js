(function(window, undefined) {
  var dictionary = {
    "d6ef65c2-cb6a-49dd-9b22-92729c48fda1": "end",
    "e96fe01c-501f-44a7-9085-eaede8092be3": "test1",
    "a6c33432-3d99-4d71-9b9a-23e6817e1a65": "screen3",
    "5f352621-d036-4bee-82bc-242630eb67c4": "test",
    "3ffb8bac-90d8-41d3-9a2e-efff5bfe6f6d": "Splash screen",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);