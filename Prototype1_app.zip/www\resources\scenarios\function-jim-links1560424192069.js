(function(window, undefined) {

  var jimLinks = {
    "e96fe01c-501f-44a7-9085-eaede8092be3" : {
      "raised_Button_5" : [
        "5f352621-d036-4bee-82bc-242630eb67c4"
      ]
    },
    "a6c33432-3d99-4d71-9b9a-23e6817e1a65" : {
      "raised_Button_5" : [
        "e96fe01c-501f-44a7-9085-eaede8092be3"
      ],
      "raised_Button_6" : [
        "d6ef65c2-cb6a-49dd-9b22-92729c48fda1"
      ]
    },
    "5f352621-d036-4bee-82bc-242630eb67c4" : {
      "raised_Button_5" : [
        "a6c33432-3d99-4d71-9b9a-23e6817e1a65"
      ]
    },
    "3ffb8bac-90d8-41d3-9a2e-efff5bfe6f6d" : {
      "Image_73" : [
        "e96fe01c-501f-44a7-9085-eaede8092be3"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);